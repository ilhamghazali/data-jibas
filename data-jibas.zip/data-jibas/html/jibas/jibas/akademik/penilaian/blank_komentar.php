<?
/**[N]**
 * JIBAS Education Community
 * Jaringan Informasi Bersama Antar Sekolah
 * 
 * @version: 16.2 (March 12, 2019)
 * @notes: JIBAS Education Community will be managed by Yayasan Indonesia Membaca (http://www.indonesiamembaca.net)
 * 
 * Copyright (C) 2009 Yayasan Indonesia Membaca (http://www.indonesiamembaca.net)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 **[N]**/ ?>
<?
//include('../cek.php');
?>
<html>
<head>
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="../css/mystyle.css">
</head>
<body>
<table border="0" width="100%" height="100%">
<tr>
    <td align="center" valign="middle" background="../images/ico/b_komentar.png"
    style="background-repeat:no-repeat;">
        <p><font size="2" color="#757575"><b>Click pada tombol &quot;Lihat Komentar&quot;
        untuk melihat daftar komentar atau </b></font></p>
        <p><font size="2" color="#757575"><b>tombol &quot;Input Komentar&quot; untuk mengisi
        komentar.</b></font></p></td>
</tr>
</table>
</body>
</html>