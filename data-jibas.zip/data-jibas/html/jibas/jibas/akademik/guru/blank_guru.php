<?
/**[N]**
 * JIBAS Education Community
 * Jaringan Informasi Bersama Antar Sekolah
 * 
 * @version: 16.2 (March 12, 2019)
 * @notes: JIBAS Education Community will be managed by Yayasan Indonesia Membaca (http://www.indonesiamembaca.net)
 * 
 * Copyright (C) 2009 Yayasan Indonesia Membaca (http://www.indonesiamembaca.net)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 **[N]**/ ?>
<html>
<head>
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="../style/style.css">
</head>
<body>
<table width="100%" border="0" height="100%" >
<tr></tr>
<tr>
    <td align="center" valign="top" background="../images/ico/b_guru.png"
    style="background-repeat:no-repeat;">
    <table border="0"width="100%">
    <!-- TABLE TITLE -->
    <tr>
     
      <td width="50%" align="right" valign="top"><div align="right"><font size="4" face="Verdana, Arial, Helvetica, sans-serif" style="background-color:#ffcc66">&nbsp;</font>&nbsp;<font size="4" face="Verdana, Arial, Helvetica, sans-serif" color="Gray">Pendataan Guru</font></div></td>
    </tr>
    
    <tr>
      <td align="left" valign="top"><div align="right"><a href="../guru.php?page=g" target="content">
        <font size="1" color="#000000"><b>Guru & Pelajaran</b></font></a>&nbsp>&nbsp <font size="1" color="#000000"><b>Guru</b></font> </div></td>
    </tr>
    
	</table><br><br><br><br><br><br><br><br><br><br>
        <font size="2" color="#757575"><b>Klik pada tombol "<strong>Tampilkan Semua Guru</strong>" atau <em>hyperlink</em> "<strong>Pelajaran</strong>" di panel kiri untuk menampilkan pendataan guru</b></font>    </td>
</tr>
</table>
</body>
</html>