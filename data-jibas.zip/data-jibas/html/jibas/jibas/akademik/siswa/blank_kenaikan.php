<?
/**[N]**
 * JIBAS Education Community
 * Jaringan Informasi Bersama Antar Sekolah
 * 
 * @version: 16.2 (March 12, 2019)
 * @notes: JIBAS Education Community will be managed by Yayasan Indonesia Membaca (http://www.indonesiamembaca.net)
 * 
 * Copyright (C) 2009 Yayasan Indonesia Membaca (http://www.indonesiamembaca.net)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 **[N]**/ ?>
<html>
<head>
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="../style/style.css">
</head>
<body>
<table width="100%" border="0" height="100%">
<tr height="200">
    <td>
      <table width="100%" border="0" height="100%">
  	<tr>
    <td align="center" valign="top">
    	<br /><br /><br /><br /><br />    	
    	<font size="2" color="#757575"><b>Klik pada tombol &quot;Tampil&quot;, &quot;Cari&quot; atau &quot;Lihat&quot; untuk
      menampilkan daftar siswa yang akan naik kelas &nbsp;</b></font></td>
    </tr>
	</table>
	</td>
</tr>
</table>
</body>
</html>