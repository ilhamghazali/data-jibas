<?
/**[N]**
 * JIBAS Education Community
 * Jaringan Informasi Bersama Antar Sekolah
 * 
 * @version: 16.2 (March 12, 2019)
 * @notes: JIBAS Education Community will be managed by Yayasan Indonesia Membaca (http://www.indonesiamembaca.net)
 * 
 * Copyright (C) 2009 Yayasan Indonesia Membaca (http://www.indonesiamembaca.net)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 **[N]**/ ?>
<frameset rows="85,*" border="1" framespacing="yes" frameborder="yes">
		<frame src="alumni_header.php" name="alumni_header" scrolling="No" noresize="noresize" id="alumni_header" title="alumni_header" style="border:1; border-bottom-color:#000000; border-bottom-style:solid" />
		<frame src="blank_alumni_all.php" name="alumni_footer" scrolling="auto" noresize="noresize" id="alumni_footer" title="alumni_footer"/>
</frameset><noframes></noframes>

<!--<frameset cols="375,*" frameborder="yes" border="1" framespacing="yes"> 
	<frameset rows="220,*" border="1" framespacing="yes">
		<frame src="alumni_menu.php" name="alumni_menu" id="alumni_menu">
		<frame src="../blank_white.php"  name="alumni_pilih" id="alumni_pilih" style="border:1; border-top-color:#000000; border-top-style:solid">
	</frameset>
	<frame src="blank_alumni.php" name="alumni_content" id="alumni_content" style="border:1; border-left-color:#000000; border-left-style:solid">
</frameset><noframes></noframes>-->